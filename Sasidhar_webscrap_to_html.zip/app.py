
# imports
from flask import Flask, render_template, request
#from flask_cors import CORS, cross_origin
import requests
from bs4 import BeautifulSoup as bs
from urllib.request import urlopen as uOpen
from urllib.request import Request
import pandas as pd
from IPython.core.display import HTML



app = Flask(__name__) # initialising the flask app with the name 'app'

# base url + /
# http://localhost:8000 + /

@app.route('/', methods = ['GET']) # route with allowed methods as POST and GET
def load_file():
	return render_template('ET_web.html')

def getnews():

    try:
        #extracting data from Dailyhunt
        dailyhunt_url = 'https://m.dailyhunt.in/news/india/english'
        ET_url = 'https://economictimes.indiatimes.com/'
        dh_page = get_webpage(dailyhunt_url)
        ET_page = get_webpage(ET_url)

        #retrieving news from dailyhunt website
        dh_news_boxes = dh_page.findAll("li", {"class": 'lang_en'})  # getting the news boxes

        #segrregating data into different columns
        dh_data = []
        for news in dh_news_boxes:
            b = news.find('a')
            link = ""
            if (b is not None):  # if find doesn't return a 'NoneType' object
                if (b.has_attr('href')):  # if 'a' tag has the attribute 'href'
                    link = b['href']
            else:
                continue
            channel = news.find('span').text.strip()
            quote = news.find('h2').text.strip()
            time_pub = news.find('em').text.strip()
            dh_data.append([channel,quote,link,time_pub])


        # extracting data from Economic Times
        top_news_tag = ET_page.find("li",{"data-ga-action": 'Widget Top News'})  # getting headlines from  "Top News tab
        news_list = top_news_tag.findAll("li")

        #seggregating data into different columns
        et_data = []
        for news in news_list:
            b = news.find('a')
            link = ""
            if (b is not None):  # if find doesn't return a 'NoneType' object
                if (b.has_attr('href')):  # if 'a' tag has the attribute 'href'
                    href = b['href']
                    link = ET_url + href[1:len(href)]
            else:
                continue
            headline = news.text.strip()
            result = requests.get(link)
            res_html = bs(result.text, "html.parser")
            text_link = res_html.find('div', {'class': 'artText'})
            fig = res_html.find('figure', {'class': 'artImg'})
            img_ref = ' '
            if(fig is not None):
                img = fig.find('img')
                if (img is not None):
                    img_ref = img['src']


            date = ""
            date_link = res_html.find('time')
            if (date_link is not None):
                date = date_link.text

            if (text_link is not None):
                et_data.append([img_ref, date, headline, text_link.text])
                #et_data.append([img_ref, date, headline, text_link.text, link])

        # storing the extracted data in data frames
        dh_frame = pd.DataFrame(dh_data,columns=['Channel','Headline','Link','Published_Time'])
        et_frame = pd.DataFrame(et_data,columns=['Image','Date','Headline','Article'])

        # writing data to csv files from data frames
        
        filename_dh = 'Dailyhunt.csv'
        filename_et = 'Economictimes.csv'
        dh_frame.to_csv(filename_dh)
        et_frame.to_csv(filename_et)
		#writng the dataframe data to html table
        HTML(et_frame.to_html('.\\templates\\ET_web.html', escape=False, formatters=dict(Image=image_link_to_html_tag),justify='center'))

    except Exception as e:
        print(e)

def get_webpage(url):
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    dh_client = uOpen(req)  # retrieeving the dailyhunt webpage  from internet
    page_content = dh_client.read()  # reading teh web page
    dh_client.close()  # closing the connection to teh server
    html_page = bs(page_content, "html.parser")  # parsing the web page as html
    return html_page

# converts image link to html tag format
def image_link_to_html_tag(image_link):
    return '<img src="'+ image_link + '" width="120" >'


if __name__ == "__main__":
    getnews()
    app.run(port=8000,debug=True) # running the app on the local machine on port 8000



















